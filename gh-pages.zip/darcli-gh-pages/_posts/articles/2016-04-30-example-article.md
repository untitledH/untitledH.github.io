---
layout: post
title: Example article
date: 2016-05-01 12:00:00
categories: articles
comments: false
en: true
description: An example article to this theme
pt: /articles/example-article-pt-br/
description_pt: Um artigo de exemplo para esse tema
keywords: "Key, words, about, this, article, to, SEO"
authors:
    - author1
    - author2
---

This is a example article.

Look, the difference between this article and the [example post]({{ site.baseurl }}/posts/examplo-post/) is that this page, `comments` are disable and `categories` was changed from `posts` to `articles`.
