---
layout: post
title: Título do artigo
date: 2016-04-30 01:00:00
categories: articles
en: false
comments: false
description: descrição do artigo para SEO
keywords: "palavras, chaves, desse, artigo, para, SEO"
authors:
    - author1
    - author2
---

Esse é só um exemplo de artigo, você pode ver melhor exemplo de texto no [example post]({{ site.baseurl }}/posts/example-post/).

Note que a diferença para esse artigo e o exemplo de post é que nessa página, os comentários estão desabilitados e a categoria foi mudada de `post` para `articles`, mudando o lugar em que ele é listado na index.
