---
layout: post
title: Título do post
date: 2016-04-30 01:00:00
categories: posts
en: false
comments: true
description: descrição do post para SEO
keywords: "palavras, chaves, desse, post, para, SEO"
authors:
    - author1
    - author2
---

Exemplo de post, digamos que seria uma tradução para outra língua. Então, basta marcar a variável `en` como `false` que o post não será listado novamente na `index.html`.

No mais, basta deixar as variáveis como estão ou ir testando, está tudo bem intuitivo.
